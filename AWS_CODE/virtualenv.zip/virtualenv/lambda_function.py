import json
import numpy as np
from pyproj import Proj, transform
import xlrd
import boto3
import gmplot
import math
import numpy
from scipy.ndimage import map_coordinates

#functions for multilateration.
#this library is more or less based around the so-called "GPS equation", the canonical
#iterative method for getting position from GPS satellite time difference of arrival data.
#we have multiple fixed stations with known time references (GPSDO) and known
#locations (again, GPSDO).
########################END NOTES#######################################


#this is a 10x10-degree WGS84 geoid datum, in meters relative to the WGS84 reference ellipsoid. given the maximum slope, you should probably interpolate.
#NIMA suggests a 2x2 interpolation using four neighbors. we'll go cubic spline JUST BECAUSE WE CAN
wgs84_geoid = numpy.array([[13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13,13],                       #90N
               [3,1,-2,-3,-3,-3,-1,3,1,5,9,11,19,27,31,34,33,34,33,34,28,23,17,13,9,4,4,1,-2,-2,0,2,3,2,1,1],                                       #80N
               [2,2,1,-1,-3,-7,-14,-24,-27,-25,-19,3,24,37,47,60,61,58,51,43,29,20,12,5,-2,-10,-14,-12,-10,-14,-12,-6,-2,3,6,4],                    #70N
               [2,9,17,10,13,1,-14,-30,-39,-46,-42,-21,6,29,49,65,60,57,47,41,21,18,14,7,-3,-22,-29,-32,-32,-26,-15,-2,13,17,19,6],                 #60N
               [-8,8,8,1,-11,-19,-16,-18,-22,-35,-40,-26,-12,24,45,63,62,59,47,48,42,28,12,-10,-19,-33,-43,-42,-43,-29,-2,17,23,22,6,2],            #50N
               [-12,-10,-13,-20,-31,-34,-21,-16,-26,-34,-33,-35,-26,2,33,59,52,51,52,48,35,40,33,-9,-28,-39,-48,-59,-50,-28,3,23,37,18,-1,-11],     #40N
               [-7,-5,-8,-15,-28,-40,-42,-29,-22,-26,-32,-51,-40,-17,17,31,34,44,36,28,29,17,12,-20,-15,-40,-33,-34,-34,-28,7,29,43,20,4,-6],       #30N
               [5,10,7,-7,-23,-39,-47,-34,-9,-10,-20,-45,-48,-32,-9,17,25,31,31,26,15,6,1,-29,-44,-61,-67,-59,-36,-11,21,39,49,39,22,10],           #20N
               [13,12,11,2,-11,-28,-38,-29,-10,3,1,-11,-41,-42,-16,3,17,33,22,23,2,-3,-7,-36,-59,-90,-95,-63,-24,12,53,60,58,46,36,26],             #10N
               [22,16,17,13,1,-12,-23,-20,-14,-3,14,10,-15,-27,-18,3,12,20,18,12,-13,-9,-28,-49,-62,-89,-102,-63,-9,33,58,73,74,63,50,32],          #0
               [36,22,11,6,-1,-8,-10,-8,-11,-9,1,32,4,-18,-13,-9,4,14,12,13,-2,-14,-25,-32,-38,-60,-75,-63,-26,0,35,52,68,76,64,52],                #10S
               [51,27,10,0,-9,-11,-5,-2,-3,-1,9,35,20,-5,-6,-5,0,13,17,23,21,8,-9,-10,-11,-20,-40,-47,-45,-25,5,23,45,58,57,63],                    #20S
               [46,22,5,-2,-8,-13,-10,-7,-4,1,9,32,16,4,-8,4,12,15,22,27,34,29,14,15,15,7,-9,-25,-37,-39,-23,-14,15,33,34,45],                      #30S
               [21,6,1,-7,-12,-12,-12,-10,-7,-1,8,23,15,-2,-6,6,21,24,18,26,31,33,39,41,30,24,13,-2,-20,-32,-33,-27,-14,-2,5,20],                   #40S
               [-15,-18,-18,-16,-17,-15,-10,-10,-8,-2,6,14,13,3,3,10,20,27,25,26,34,39,45,45,38,39,28,13,-1,-15,-22,-22,-18,-15,-14,-10],           #50S
               [-45,-43,-37,-32,-30,-26,-23,-22,-16,-10,-2,10,20,20,21,24,22,17,16,19,25,30,35,35,33,30,27,10,-2,-14,-23,-30,-33,-29,-35,-43],      #60S
               [-61,-60,-61,-55,-49,-44,-38,-31,-25,-16,-6,1,4,5,4,2,6,12,16,16,17,21,20,26,26,22,16,10,-1,-16,-29,-36,-46,-55,-54,-59],            #70S
               [-53,-54,-55,-52,-48,-42,-38,-38,-29,-26,-26,-24,-23,-21,-19,-16,-12,-8,-4,-1,1,4,4,6,5,4,2,-6,-15,-24,-33,-40,-48,-50,-53,-52],     #80S
               [-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30,-30]], #90S
               dtype=numpy.float)

#ok this calculates the geoid offset from the reference ellipsoid
#combined with LLH->ECEF this gets you XYZ for a ground-referenced point
def wgs84_height(lat, lon):
    yi = numpy.array([9-lat/10.0])
    xi = numpy.array([18+lon/10.0])
    return float(map_coordinates(wgs84_geoid, [yi, xi]))

#WGS84 reference ellipsoid constants
wgs84_a = 6378137.0
wgs84_b = 6356752.314245
wgs84_e2 = 0.0066943799901975848
wgs84_a2 = wgs84_a**2 #to speed things up a bit
wgs84_b2 = wgs84_b**2

#convert ECEF to lat/lon/alt without geoid correction
#returns alt in meters
def ecef2llh(ecef):
    x, y, z = ecef
    ep  = math.sqrt((wgs84_a2 - wgs84_b2) / wgs84_b2)
    p   = math.sqrt(x**2+y**2)
    th  = math.atan2(wgs84_a*z, wgs84_b*p)
    lon = math.atan2(y, x)
    lat = math.atan2(z+ep**2*wgs84_b*math.sin(th)**3, p-wgs84_e2*wgs84_a*math.cos(th)**3)
    N   = wgs84_a / math.sqrt(1-wgs84_e2*math.sin(lat)**2)
    alt = p / math.cos(lat) - N

    lon *= (180. / math.pi)
    lat *= (180. / math.pi)

    return [lat, lon, alt]

#convert lat/lon/alt coords to ECEF without geoid correction, WGS84 model
#remember that alt is in meters
def llh2ecef(lla):
    lat, lon, alt = lla
    lat *= (math.pi / 180.0)
    lon *= (math.pi / 180.0)

    n = lambda x: wgs84_a / math.sqrt(1 - wgs84_e2*(math.sin(x)**2))

    x = (n(lat) + alt)*math.cos(lat)*math.cos(lon)
    y = (n(lat) + alt)*math.cos(lat)*math.sin(lon)
    z = (n(lat)*(1-wgs84_e2)+alt)*math.sin(lat)

    return [x,y,z]

#do both of the above to get a geoid-corrected x,y,z position
def llh2geoid(lla):
    lat, lon, alt = lla
    (x,y,z) = llh2ecef((lat, lon, alt + wgs84_height(lat, lon)))
    return [x,y,z]


c = 343 #modified for refractive index of air, why not

#this function is the iterative solver core of the mlat function below
#we use limit as a goal to stop solving when we get "close enough" (error magnitude in meters for that iteration)
#it's possible this could fail in situations where the solution converges slowly
#TODO: this fails to converge for some seriously advantageous geometry
def mlat_iter(rel_stations, prange_obs, xguess = [0,0,0], limit = 20, maxrounds = 100):
    xerr = [1e9, 1e9, 1e9]
    rounds = 0
    while numpy.linalg.norm(xerr) > limit:
        prange_est = [[numpy.linalg.norm(station - xguess)] for station in rel_stations]
        dphat = prange_obs - prange_est
        H = numpy.array([(numpy.array(-rel_stations[row,:])+xguess) / prange_est[row] for row in range(0,len(rel_stations))])
        #now we have H, the Jacobian, and can solve for residual error
        xerr = numpy.linalg.lstsq(H, dphat)[0].flatten()
        xguess += xerr
        #print xguess, xerr
        rounds += 1
        if rounds > maxrounds:
            raise Exception("Failed to converge!")
            break
    return xguess

#func mlat:
#uses a modified GPS pseudorange solver to locate by multilateration.
#replies is a list of reports, in ([lat, lon, alt], timestamp) format
#returns the estimated position in (lat, lon, alt) geoid-corrected WGS84.
#let's make it take a list of tuples so we can sort by them
def mlat(replies, altitude):
    sorted_replies = sorted(replies, key=lambda time: time[1])

    stations = [sorted_reply[0] for sorted_reply in sorted_replies]
    timestamps = [sorted_reply[1] for sorted_reply in sorted_replies]

    me_llh = stations[0]
    me = llh2geoid(stations[0])


    #list of stations in XYZ relative to me
    rel_stations = [numpy.array(llh2geoid(station)) - numpy.array(me) for station in stations[1:]]
    rel_stations.append([0,0,0] - numpy.array(me))
    rel_stations = numpy.array(rel_stations) #convert list of arrays to 2d array

    #differentiate the timestamps to get TDOA, multiply by c to get pseudorange
    prange_obs = [[c*(stamp-timestamps[0])] for stamp in timestamps[1:]]

    #so here we calc the estimated pseudorange to the center of the earth, using station[0] as a reference point for the geoid
    #if the dang earth were actually round this wouldn't be an issue
    prange_obs.append( [numpy.linalg.norm(llh2ecef((me_llh[0], me_llh[1], altitude)))] ) #use ECEF not geoid since alt is MSL not GPS
    prange_obs = numpy.array(prange_obs)

    #xguess = llh2ecef([37.617175,-122.400843, 8000])-numpy.array(me)
    #xguess = [0,0,0]
    xguess = numpy.array(llh2ecef([me_llh[0], me_llh[1], altitude])) - numpy.array(me)

    xyzpos = mlat_iter(rel_stations, prange_obs, xguess)
    llhpos = ecef2llh(xyzpos+me)

    #now, we could return llhpos right now and be done with it.
    #but the assumption we made above, namely that the aircraft is directly above the
    #nearest station, results in significant error due to the oblateness of the Earth's geometry.
    #so now we solve AGAIN, but this time with the corrected pseudorange of the aircraft altitude
    #this might not be really useful in practice but the sim shows >50m errors without it
    #and <4cm errors with it, not that we'll get that close in reality but hey let's do it right
    prange_obs[-1] = [numpy.linalg.norm(llh2ecef((llhpos[0], llhpos[1], altitude)))]
    xyzpos_corr = mlat_iter(rel_stations, prange_obs, xyzpos) #start off with a really close guess
    llhpos = ecef2llh(xyzpos_corr+me)

    #and now, what the hell, let's try to get dilution of precision data
    #avec is the unit vector of relative ranges to the aircraft from each of the stations
#    for i in range(len(avec)):
#        avec[i] = numpy.array(avec[i]) / numpy.linalg.norm(numpy.array(avec[i]))
#    numpy.append(avec, [[-1],[-1],[-1],[-1]], 1) #must be # of stations
#    doparray = numpy.linalg.inv(avec.T*avec)
#the diagonal elements of doparray will be the x, y, z DOPs.

    return llhpos

def lookup_uid(uid):
    #opens a excel doc that contains gps coordinates based on eui of xDot
    xl = xlrd.open_workbook("gps_demo.xlsx")
    sheet = xl.sheet_by_index(0)
    for i in range(sheet.nrows):
      if sheet.row_values(i)[0] == uid:
          index = i
          break
      else:
          continue
    gps1 = [sheet.row_values(index)[1], sheet.row_values(index)[2]]
    xl.release_resources()
    del xl
    return gps1

def multilateration(s_1, s_2, s_3):
    """s_1, s_2, s_3 are matrixes of size 3x1
    s_i = [x_i, y_i, t_i] where x_i is the x coordinate
    and y_i is y coordinate and t_i is TOA of sound """

    ones = np.ones(shape=(3,1))
    A = np.zeros(shape=(3,3))
    A[:, 0] = s_1
    A[:, 1] = s_2
    A[:, 2] = s_3

    b = np.zeros(shape=(3,1))
    b[0] = s_1[0]**2 + s_1[1]**2 - s_1[2]**2
    b[1] = s_2[0]**2 + s_2[1]**2 - s_2[2]**2
    b[2] = s_3[0]**2 + s_3[1]**2 - s_3[2]**2

    d = 0.5 * np.dot(np.linalg.inv(A),ones)
    e = 0.5 * np.dot(np.linalg.inv(A),b)

    alpha = np.inner(d, d)
    beta = 2 * np.inner(d, e)
    gamma = np.inner(e, e)

    lambda_plus = 1/(2*alpha) * (-beta + np.sqrt(beta**2 + 4*alpha*gamma))
    lambda_minus = 1/(2*alpha) * (-beta + np.sqrt(beta**2 - 4*alpha*gamma))

    s_a = np.dot(lambda_plus,d) + e
    s_a_temp = np.dot(lambda_minus,d) + e

    return s_a

def convert_back_to_gps(x1, y1):
    #function to convert xy coordinates back to gps in format of WGS84
    isn2004=Proj("+proj=lcc +lat_1=64.25 +lat_2=65.75 +lat_0=65 +lon_0=-19 +x_0=1700000 +y_0=300000 +no_defs +a=6378137 +rf=298.257222101 +to_meter=1")
    wgs84=Proj("+init=EPSG:4326") # LatLon with WGS84 datum used by GPS units and Google Earth
    y , x = transform(isn2004, wgs84,x1,y1)
    return x,y

def convert_to_xy(lat, lon):
    #function to convert gps WGS84 coordinates to xy coordinates
    #WGS84 is the universal coordinate system used by GPS units and Google Earth
    isn2004=Proj("+proj=lcc +lat_1=64.25 +lat_2=65.75 +lat_0=65 +lon_0=-19 +x_0=1700000 +y_0=300000 +no_defs +a=6378137 +rf=298.257222101 +to_meter=1")
    wgs84=Proj("+init=EPSG:4326")
    x,y = transform(wgs84, isn2004, lat, lon)
    return x, y

def grab_nodes(filename):
    #function to grab the device info of xDots that heard a gunshot!
    #insert s3 read line
    BUCKET = 'safedetect2'
    FILE_TO_READ = filename
    client = boto3.client('s3', aws_access_key_id='AKIAXTEC7YEPHA65OUZM', aws_secret_access_key='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')
    result = client.get_object(Bucket=BUCKET, Key=FILE_TO_READ)
    data = result['Body'].read().decode('utf-8')
    data=json.loads(data)
    eui = data["eui"]
    timestamp = data["timestamp"]
    return eui, timestamp

def eui_from_json(filename):
    #function to read eui from json
    #make sure filename is string
    with open(filename, "r") as read_file:
        data = json.load(read_file)
        eui = data["eui"]
    return eui

def map_it(lat, lon):
    gmap = gmplot.GoogleMapPlotter(34.025277, -118.291241, 10)
    gmap.marker(lat, lon, 'cornflowerblue')
    gmap.marker(lat, lon, 'cornflowerblue')
    gmap.draw('/tmp/mymap.html')
    BUCKET = 'safedetect2'
    client = boto3.client('s3', aws_access_key_id='AKIAXTEC7YEPHA65OUZM', aws_secret_access_key='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')
    client.upload_file('/tmp/mymap.html', BUCKET, 'mymap.html')

def time_diff(t1, t2, t3):
    t1 = float(t1)
    t2 = float(t2)
    t3 = float(t3)

    if(t1 < t2):
        if(t1 <= t3):
            t2 = t2-t1
            t3 = t3-t1
            t1 = 0
            return t1, t2, t3
        if(t1 > t3):
            t1 = t3 - t1
            t2 = t3 - t1
            t3 = 0
            return t1, t2, t3
    elif(t2 < t1):
        if(t2 <= t3):
            t3 = t3 - t2
            t1 = t1 - t2
            t2 = 0
            return t1, t2, t3
        if(t2 > t3):
            t1 = t1 - t3
            t2 = t2 - t3
            t3 = 0
            return t1, t2, t3
    elif(t3 < t1):
        if(t3 < t2):
            t1 = t1 - t3
            t2 = t2 - t3
            t3 = 0
            return t1, t2, t3
        if(t3 >= t2):
            t1 = t1-t2
            t3 = t3-t2
            t2 = 0
            return t1, t2, t3

def email(x,y):
    from botocore.exceptions import ClientError
    # Replace sender@example.com with your "From" address.
    # This address must be verified with Amazon SES.
    SENDER = "SafeDetect <shikariiiv@gmail.com>"

    # Replace recipient@example.com with a "To" address. If your account
    # is still in the sandbox, this address must be verified.
    RECIPIENT = "shikariiiv@gmail.com"

    # If necessary, replace us-west-2 with the AWS Region you're using for Amazon SES.
    AWS_REGION = "us-east-1"

    # The subject line for the email.
    SUBJECT = "Amazon SES Notification"

    # The email body for recipients with non-HTML email clients.
    BODY_TEXT = ("Coordinates of Gunshot\r\n"
                "Thank you")

    # The HTML body of the email.
    BODY_HTML = """<html>
    <head></head>
    <body>
      <h1>Coordinates of Gunshot</h1>
      """ +str(x) + " " + str(y)+ """
      <p>This email was sent with
        <a href='https://aws.amazon.com/ses/'>Amazon SES</a> using the
        <a href='https://aws.amazon.com/sdk-for-python/'>
          AWS SDK for Python (Boto)</a>.</p>
    </body>
    </html>
                """

    # The character encoding for the email.
    CHARSET = "UTF-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses',region_name=AWS_REGION)

    # Try to send the email.
    try:
        #Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
            # If you are not using a configuration set, comment or delete the
            # following line
            #ConfigurationSetName=CONFIGURATION_SET,
        )
    # Display an error if something goes wrong.
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])

def lambda_handler(event, context):
    # TODO implement
    #lambda function, kind of like main function
    uid1, t1 = grab_nodes("node1.json")
    uid2, t2 = grab_nodes("node2.json")
    uid3, t3 = grab_nodes("node3.json")
    print("dev. id and timestamp: ", uid1, ",", t1)
    print("dev. id and timestamp: ", uid2, ",", t2)
    print("dev. id and timestamp: ", uid3, ",", t3)

    t1, t2, t3 = time_diff(t1, t2, t3)

    gps1 = lookup_uid(uid1)
    gps2 = lookup_uid(uid2)
    gps3 = lookup_uid(uid3)
    print("node1 location: ",gps1)
    print("node2 location: ",gps2)
    print("node3 location: ",gps3)

    teststations = [[gps1[0], gps1[1], 55.77], [gps2[0], gps2[1], 55.77], [gps3[0], gps3[1], 55.77]]
    testalt      = 60
    testplane    = numpy.array(llh2ecef([gps1[0], gps1[1], testalt]))
    testme       = llh2geoid(teststations[0])
    t = min([t1, t2, t3])
    teststamps   = [0,
                    numpy.linalg.norm(testplane-numpy.array(llh2geoid(teststations[1]))) / c,
                    numpy.linalg.norm(testplane-numpy.array(llh2geoid(teststations[2]))) / c]
    replies = []
    for i in range(0, len(teststations)):
        replies.append((teststations[i], teststamps[i]))
    ans = mlat(replies, testalt)

    print(ans)

    map_it(ans[0],ans[1])
    email(ans[0],ans[1])
    return {
        'statusCode': 100,
        'body': json.dumps('this is where the gunshot occurred'),
        'lat' : json.dumps(ans[0]),
        'long': json.dumps(ans[1])
    }
