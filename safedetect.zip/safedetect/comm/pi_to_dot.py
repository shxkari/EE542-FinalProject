# Module for sending from pi to dot

import time
import serial
import sys
import datetime
print (sys.argv)

device = '/dev/ttyACM1'
ser = serial.Serial(device)

def init_connection():
	ser.baudrate = 9600
	ser.flushOutput()
	ser.flushInput()
	
# pass in confidence and max_val as numbers and they can be 
# converted to string
def data_to_str(confidence):
	text = "C:" + str(confidence) + '!'
	return text

# takes in a string and send to the dot
def send_to_dot(to_send):
	line = "not"
	# holds the pi here until the dot is able to transmit
	while "ready" not in line:
		line = ser.readline()
		line = line.decode('ascii')
	ser.write(to_send.encode())

def send_curr_time(): 
	line = "not"
	# holds the pi here until the dot is able to transmit
	while "ready" not in line:
		line = ser.readline()
		line = line.decode('ascii')
	t = datetime.time()
	to_send = str(t.minute) + "," + str(t.second) + "," + str(t.microsecond) + "!"
	ser.write(to_send.encode())

''' 
Use: 

init_connection()
send_to_dot(data_to_str(34.5))

see ser_ex.py
'''
