#include "mbed.h"              
#include "dot_util.h"
#include "RadioEvent.h"
#include <stdlib.h> 
#include <inttypes.h>


// setting must match settings on the gateway
static std::string network_name = "LAleakers";
static std::string network_passphrase = "stephisbroke";
static uint8_t network_id[] = { 0x6C, 0x4E, 0xEF, 0x66, 0xF4, 0x79, 0x86, 0xA6 };
static uint8_t network_key[] = { 0x1F, 0x33, 0xA1, 0x70, 0xA5, 0xF1, 0xFD, 0xA0, 0xAB, 0x69, 0x7A, 0xAE, 0x2B, 0x95, 0x91, 0x6B };
static uint8_t frequency_sub_band = 7;
static lora::NetworkType network_type = lora::PUBLIC_LORAWAN;
static uint8_t join_delay = 5;
static uint8_t ack = 0;
static bool adr = false;

static bool deep_sleep = false;

mDot* dot = NULL;
lora::ChannelPlan* plan = new lora::ChannelPlan_US915();

Serial pc(USBTX, USBRX);

I2C i2c(I2C_SDA, I2C_SCL);

DigitalOut led(LED1);
DigitalIn  start_signal(GPIO2);

int main() {
    //pc.printf("Echoes back to the screen anything you type\n");
    
    RadioEvent events;
    printf("HELLO!!!\n");
    pc.printf("Hi from pc\n");
    //pc.baud(115200);
    
    i2c.frequency(400000);

    //mts::MTSLog::setLogLevel(mts::MTSLog::TRACE_LEVEL);

    assert(plan);

    dot = mDot::getInstance(plan);
    assert(dot);

    // attach the custom events handler
    dot->setEvents(&events);
    
    //printf("S");
    
    if (!dot->getStandbyFlag()) {
        logInfo("mbed-os library version: %d.%d.%d", MBED_MAJOR_VERSION, MBED_MINOR_VERSION, MBED_PATCH_VERSION);

        // start from a well-known state
        logInfo("defaulting Dot configuration");
        dot->resetConfig();
        dot->resetNetworkSession();

        // make sure library logging is turned on
        //dot->setLogLevel(mts::MTSLog::INFO_LEVEL);

        // update configuration if necessary
        if (dot->getJoinMode() != mDot::OTA) {
            logInfo("changing network join mode to OTA");
            if (dot->setJoinMode(mDot::OTA) != mDot::MDOT_OK) {
                logError("failed to set network join mode to OTA");
            }
        }
        // in OTA and AUTO_OTA join modes, the credentials can be passed to the library as a name and passphrase or an ID and KEY
        // only one method or the other should be used!
        // network ID = crc64(network name)
        // network KEY = cmac(network passphrase)
        update_ota_config_name_phrase(network_name, network_passphrase, frequency_sub_band, network_type, ack);
        //update_ota_config_id_key(network_id, network_key, frequency_sub_band, network_type, ack);

        // configure network link checks
        // network link checks are a good alternative to requiring the gateway to ACK every packet and should allow a single gateway to handle more Dots
        // check the link every count packets
        // declare the Dot disconnected after threshold failed link checks
        // for count = 3 and threshold = 5, the Dot will ask for a link check response every 5 packets and will consider the connection lost if it fails to receive 3 responses in a row
        //update_network_link_check_config(3, 5);
        
        // enable or disable Adaptive Data Rate
        dot->setAdr(adr);

        // Configure the join delay
        dot->setJoinDelay(join_delay);

        // save changes to configuration
        logInfo("saving configuration");
        if (!dot->saveConfig()) {
            logError("failed to save configuration");
        }
        
        // display configuration
        display_config();
    } else {
        // restore the saved session if the dot woke from deepsleep mode
        // useful to use with deepsleep because session info is otherwise lost when the dot enters deepsleep
        logInfo("restoring network session from NVM");
        dot->restoreNetworkSession();
    }
    
    // join network if not joined
    if (!dot->getNetworkJoinStatus()) {
        join_network();
        pc.printf("joining network\r");
    }
    
    printf("TX DR: %i\r", dot->getTxDataRate());
    
    uint8_t max_dr = dot->getMaxDatarate();
    
    printf("MAX DR: %i\r", max_dr);
    
    if (dot->setTxDataRate(max_dr) != mDot::MDOT_OK) {
        logError("failed to set TX datarate to DR1");
    }
    
    pc.printf("TX DR: %i\r", dot->getTxDataRate());
    int ARR_SIZE = dot->getNextTxMaxSize();
    //int t_size = 17;
    //ARR_SIZE -= t_size; 
    ARR_SIZE -= 5; // for the commas & colons in there
    char arr[ARR_SIZE];
    //char t_arr[t_size];
    int sig_start = 0;
    while (true) {
        //pc.printf("Max Payload: %i\n\r", dot->getNextTxMaxSize());
        
        /*sig_start = 0;
        sig_start = start_signal.read();
        while(sig_start == 0) {
            sig_start = start_signal.read();
            wait(1);
        }*/
        memset(arr, 0, ARR_SIZE);
        //memset(t_arr, 0, t_size); 
        
        std::vector<uint8_t> tx_data;
        tx_data.clear();    
        /*
        uint64_t gps_t = dot->getGPSTime();
        printf("%llu \n", gps_t);
        snprintf(t_arr, t_size,"T:%llu,", gps_t);*/
        
        //pc.printf("Enter a message to TX: ");
        char c = 'f';
        pc.printf("ready\n");
        //pc.printf("Your message: ");
        for(int i = 0; i < ARR_SIZE && c != '!'; i++){
            c = pc.getc();
            //pc.printf("%c", c);
            arr[i] = c;
        }
        //pc.gets(arr, 9);
        //pc.printf("sending: %s\r", arr); 
        
        /*
        for(int i = 0; i < t_size && t_arr[i] != ','; i++) {
            tx_data.push_back(t_arr[i]);   
        }
        tx_data.push_back(',');*/
        
        for(int i = 0; arr[i] != '!' && i < ARR_SIZE; i++) {
            if(arr[i] == '!'){
                break;
            }
            tx_data.push_back(arr[i]);
        }
        send_data(tx_data);
        //pc.printf("message sent... \r"); 
    }
    return 0;
}

