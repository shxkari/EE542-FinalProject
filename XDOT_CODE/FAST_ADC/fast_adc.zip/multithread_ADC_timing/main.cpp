/* mbed Microcontroller Library
 * Copyright (c) 2018 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"
#include "platform/mbed_thread.h"
#include "stats_report.h"
#include <AnalogIn.h>
#include <AnalogOut.h>
#include "circ_buff.hpp"
#include "fastADC.h"


AnalogOut v_src(GPIO0);
AnalogIn therm(GPIO2);

#define SLEEP_TIME                  500 // (msec)
#define PRINT_AFTER_N_LOOPS         20

//define defaults for mfcc
#define DEF_NUMCEPSTRA      12
#define DEF_NUMFILTERS      40
#define DEF_SAMPLINGRATE    16000
#define DEF_WINLENGTH       25
#define DEF_FRAMESHIFT      10
#define DEF_LOWFREQ         50
#define DEF_HIGHFREQ        DEF_SAMPLINGRATE/2
#define WINDOW_SIZE         DEF_WINLENGTH - DEF_FRAMESHIFT
#define ARRAY_SIZE          800
 
#define BUFFSIZE                    1000 // size of buffer = sampling_time * sampling_rate * size(float)
//DigitalOut led1(LED1);
//DigitalOut led2(LED2);
Thread thread_adc;
Thread thread_mfcc;
Ticker read_ADC_ticker;

// PIN DEFINITIONS
DigitalOut vcc(GPIO0);
AnalogIn mic(PB_0);
CircularBuff<uint16_t> buff(BUFFSIZE);

Serial pc(USBTX, USBRX);

volatile int num_readings = 0;
int z = 0;
volatile uint16_t raw_adc = 0; 
uint16_t* pop_val;

void adc_thread() {
    raw_adc = readADC();       /* Read AD converted value            */
    num_readings++;
}
/* 
    this thread is in charge of counting
*/
void mfcc_thread() {
    while (true) {
        //printf("Top of MFCC thread");
        thread_sleep_for(5000);
        double rate = num_readings/5000.0;
        pc.printf("Readings / second: %f Ksps\n\n", rate);
        num_readings = 0;
        //pop_val = buff.pop();
        //pc.printf("last reading: %u\n", *pop_val);
        //buff.clear();
    }
}

int main() {
    
    pc.printf("Creating buff of size %d\n", BUFFSIZE);

    pc.printf("Setting up ADC\n");

    initADC();
    
    read_ADC_ticker.attach_us(&adc_thread, 50);
    thread_mfcc.start(mfcc_thread);
    while(1){
        thread_sleep_for(10000);
    }
}