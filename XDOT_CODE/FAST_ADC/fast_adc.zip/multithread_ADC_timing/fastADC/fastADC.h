#ifndef FAST_ADC_H
#define FAST_ADC_H

#include <stdint.h>

void initADC();
uint16_t readADC();

#endif